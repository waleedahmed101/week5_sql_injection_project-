# Week 5 Report - Ethical Hacking & SQL Injection

## 🔎 SQL Injection Testing
- Tool used: SQLMap
- Target URL: http://localhost:3000/rest/products?id=1
- Result: SQLMap detected a SQL Injection vulnerability in the `id` parameter.

## 💻 Fix Applied
- Changed vulnerable query:
  ```js
  const q = `SELECT * FROM users WHERE id = ${req.query.id}`;
  ```
- To prepared statement:
  ```js
  const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
  ```

## ✅ Verification
- Re-ran SQLMap → no vulnerabilities found.

## 📸 Screenshots
- Add screenshots in `screenshots/` folder.
