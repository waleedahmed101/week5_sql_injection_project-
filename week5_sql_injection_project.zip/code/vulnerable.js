
// ❌ Vulnerable SQL code (DO NOT USE IN PRODUCTION)
const express = require('express');
const mysql = require('mysql2');
const app = express();
const port = 3000;

const connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  database: 'mydb'
});

app.get('/user', (req, res) => {
  const id = req.query.id;
  // 🚨 Vulnerable: directly concatenating user input
  const q = `SELECT * FROM users WHERE id = ${id}`;
  connection.query(q, (err, rows) => {
    if (err) throw err;
    res.json(rows);
  });
});

app.listen(port, () => console.log(`Vulnerable app running on port ${port}`));
