
// ✅ Fixed SQL code using prepared statements (safe)
const express = require('express');
const mysql = require('mysql2/promise');
const app = express();
const port = 3000;

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  database: 'mydb'
});

app.get('/user', async (req, res) => {
  try {
    const id = req.query.id;
    // ✅ Safe: using parameterized query
    const [rows] = await pool.execute('SELECT * FROM users WHERE id = ?', [id]);
    res.json(rows);
  } catch (err) {
    res.status(500).send('Error fetching user');
  }
});

app.listen(port, () => console.log(`Fixed app running on port ${port}`));
